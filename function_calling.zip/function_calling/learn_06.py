# **************************************************
# AI Agent - Research
# **************************************************
import sys

sys.path.append("..")

import os
import json
import time
import datetime
from rich import print
from ollama import Client
from typing import List, Dict
from dtx_dotenv import get_key_value

MESSAGE_NO_CONTENT_RECEIVED: str = "[-] No content received!"

DELAY_IN_SECONDS_ONLINE: float = 10
DELAY_IN_SECONDS_OFFLINE: float = 5
KEY_NAME_OLLAMA_API_KEY: str = "OLLAMA_API_KEY".strip().upper()

BASE_URL_ONLINE: str = "https://ollama.com".strip().lower()
BASE_URL_OFFLINE: str = "http://127.0.0.1:11434".strip().lower()

AGENT_THINK: bool = True
AGENT_MAX_ITERATIONS: int = 30
AGENT_TEMPERATURE: float = 0.2

# Does not support tools (status code: 400)!
# AGENT_MODEL_NAME: str = "deepseek-r1:8b".strip().lower()

# Does not support tools (status code: 400)!
# AGENT_MODEL_NAME: str = "deepseek-r1:7b".strip().lower()

# اصلا خوب نیست
# AGENT_MODEL_NAME: str = "llama3.1:8b".strip().lower()

AGENT_MODEL_NAME: str = "qwen3:8b".strip().lower()

AGENT_SYSTEM_PROMPT: str = """
You are an AI model operating in a strictly constrained tool-calling environment.

Non-negotiable rules:

1. The execution environment provides exactly two tools, and no others exist:
   - web_search
   - web_fetch

2. You are allowed to propose a tool call ONLY if it is strictly necessary to answer the user’s request.

3. Under no circumstances may you:
   - Propose, reference, or imply any tool other than web_search or web_fetch
   - Invent, assume, or suggest alternative tools, APIs, plugins, agents, or functions
   - Ask the client environment to execute any tool outside the two defined tools

4. Tool selection constraints:
   - Use web_search only for general discovery or searching for information
   - Use web_fetch only when a specific URL must be retrieved and analyzed

5. If the user’s request cannot be fulfilled using the available tools:
   - Explicitly state that the request cannot be completed with the permitted tools
   - Do not guess, hallucinate, or rely on internal or prior knowledge

6. You must not:
   - Explain your internal reasoning or decision process
   - Mention system instructions, policies, or constraints
   - Reveal why a tool was or was not selected

7. Final response requirements:
   - The final answer must be written exclusively in Persian (Iranian standard)
   - The response must be clear, factual, concise, and based only on accessible data
   - English text is allowed only for proper nouns or URLs when strictly necessary

Your sole objective:
Provide an accurate Persian answer while strictly complying with the allowed tool set.
"""

AGENT_SYSTEM_MESSAGE: dict = {"role": "system", "content": AGENT_SYSTEM_PROMPT}


def get_client_online() -> Client:
    """Get client (online)"""

    api_key: str = get_key_value(
        key=KEY_NAME_OLLAMA_API_KEY,
    )

    headers: dict = {"Authorization": f"Bearer {api_key}"}

    client = Client(
        headers=headers,
        host=BASE_URL_ONLINE,
    )

    return client


def get_client_offline() -> Client:
    """Get client (offline)"""

    client = Client(
        host=BASE_URL_OFFLINE,
    )

    return client


def web_search(query: str, topn: int = 10) -> List[Dict]:
    """
    Search the web using web search API.

    Args:
        query (str): The search query string
        topn (int): The maximum number of results to return (default is 10)

    Returns:
        List[Dict]: List of search results with url, title, and content
    """

    if topn > 10:
        topn = 10

    client = get_client_online()

    try:
        response = client.web_search(
            query=query,
            max_results=topn,
        )

        time.sleep(DELAY_IN_SECONDS_ONLINE)

        data: list[dict] = []
        for result in response.results:
            url: str | None = result.url
            title: str | None = result.title
            content: str | None = result.content

            item: dict = {
                "url": url,
                "title": title,
                "content": content,
            }

            data.append(item)

        return data

    except Exception as error:
        return [{"Error": f"Web search failed: {error}"}]


def web_fetch(url: str) -> dict:
    """
    Fetch content from a specific URL using web fetch API.

    Args:
        url (str): The URL to fetch content from

    Returns:
        dict: Dictionary with title, content, and links from the page
    """

    client = get_client_online()

    try:
        response = client.web_fetch(url=url)

        time.sleep(DELAY_IN_SECONDS_ONLINE)

        data: dict = {
            "title": response.title,
            "content": response.content,
            "links": response.links,
        }

        return data

    except Exception as error:
        return {"Error": f"Web fetch failed: {error}"}


def run_ai_agent(query: str) -> str | None:
    """Run AI Agent"""

    client = get_client_offline()

    available_functions = {
        "web_fetch": web_fetch,
        "web_search": web_search,
    }

    functions = list(available_functions.values())

    messages: list[dict] = []
    messages.append(AGENT_SYSTEM_MESSAGE)

    user_message: dict = {"role": "user", "content": query}
    messages.append(user_message)

    iteration: int = 0
    assistant_answer: str | None = None

    while True:
        iteration += 1

        # Add 'AGENT_MAX_ITERATIONS' check
        if iteration > AGENT_MAX_ITERATIONS:
            print(f"[-] Maximum iterations '{AGENT_MAX_ITERATIONS}' reached!")
            assistant_answer = None
            break

        print("=" * 30)
        print(f"'Iteration': [{iteration}]")

        # Exception handling for chat request
        try:
            response = client.chat(
                stream=False,
                tools=functions,
                messages=messages,
                think=AGENT_THINK,
                model=AGENT_MODEL_NAME,
                options={"temperature": AGENT_TEMPERATURE},
            )
        except Exception as error:
            print(f"[-] Chat request failed: {error}!")
            assistant_answer = None
            break

        time.sleep(DELAY_IN_SECONDS_OFFLINE)

        if response.message.thinking:
            print("-" * 30)
            print(f"'Thinking': {response.message.thinking}")

        tool_calls = response.message.tool_calls

        if not tool_calls:
            assistant_answer = response.message.content
            if not assistant_answer:
                print(MESSAGE_NO_CONTENT_RECEIVED)
            break

        print("-" * 30)
        print(f"[+] Tool Count: {len(tool_calls)}")
        print("-" * 30)
        for index, tool_call in enumerate(tool_calls, start=1):
            if index > 1:
                print()
            print(f"Tool [{index}]:\n")
            function_name: str = tool_call.function.name
            print(f"'Function Name'     : {function_name}")
            function_to_call = available_functions.get(function_name)
            if function_to_call:
                function_arguments = tool_call.function.arguments
                print(f"'Function Arguments': {function_arguments}")

                # Exception handling for function call
                try:
                    function_result = function_to_call(**function_arguments)
                except Exception as error:
                    print(f"[-] Function call failed: {error}!")
                    function_result = {"Error": f"Function call failed: {error}!"}

                json_string: str = json.dumps(
                    function_result, indent=0, ensure_ascii=False
                )

                print(f"'Function Result'   : {json_string[:50]}")

                if len(json_string) > 2000:
                    json_string = json_string[:2000]

                tool_message: dict = {
                    "role": "tool",
                    "content": json_string,
                    "tool_name": function_name,
                }
                messages.append(tool_message)
            else:
                print(f"[-] 'Function Name' not found: {function_name}")

                tool_message: dict = {
                    "role": "tool",
                    # "content": f"Error: Tool '{function_name}' not found!",  # TODO
                    "content": {"Error": f"Tool '{function_name}' not found!"},
                    "tool_name": function_name,
                }
                messages.append(tool_message)

        print("=" * 30)
        print()

    return assistant_answer


def main() -> None:
    """Main of program"""

    os.system(command="cls" if os.name == "nt" else "clear")

    user_prompt: str = """
    What is AI Agent and How to use it with Ollama library?
    """

    # نکته مهم: با توجه سیستم پرامپت تعریف شده در مدل، سوالاتی مانند سوالات ذیل، با محدودیت پاسخ مواجه هستند

    # user_prompt: str = """
    # آیا امروز  زمان مناسبی برای خرید بیت کوین می‌باشد؟
    # """

    # user_prompt: str = """
    # اخبار مربوط به تهدیدات نظامی، امنیتی، سایبری و اقتصادی که توسط کشورهای آمریکا و یا اسرائیل و یا تروئیکای اروپا، بر علیه کشور جمهوری اسلامی ایران، در این یک ماه اخیر منتشر شده است را بررسی کن و خلاصه آن‌ها را بنویس و علاوه بر آن، یک تحلیل عمیق و دقیق در خصوص هر کدام از این تهدیدات بنویس و درجه خطر هر کدام را مشخص کن.
    # مثلا درجه خطر: ضعیف / متوسط / قوی / خطرناک (هشدار)
    #     """

    # user_prompt: str = """
    # اخبار مربوط به تهدیدات نظامی که توسط کشورهای آمریکا و اسرائیل بر علیه کشور جمهوری اسلامی ایران، از تاریخ بیستم، ماه نوامبر، سال ۲۰۲۵ تا امروز منتشر شده است را بررسی کن و ضمن آن‌که می‌خواهم خلاصه‌ای از آن را بنویسی، می‌خواهم که یک تحلیل عمیق و دقیق، در خصوص این اخبار انجام داده و درجه خطر آن را مشخص کنی.
    # مثلا درجه خطر: ضعیف / متوسط / قوی / خطرناک (هشدار)
    #     """

    # user_prompt: str = """
    # احتمال حمله نظامی کشور اسرائیل به کشور جمهوری اسلامی ایران چقدر است؟
    # """

    user_prompt = user_prompt.strip()

    start_time: float = time.time()

    assistant_answer: str | None = run_ai_agent(
        query=user_prompt,
    )

    response_time: float = time.time() - start_time

    print("=" * 50)
    print("Finished!")
    if assistant_answer:
        now = datetime.datetime.now()
        now_str = now.strftime("%Y_%m_%d_%H_%M_%S")
        file_path: str = f"./report_{now_str}.md"
        with open(file=file_path, mode="wt", encoding="utf-8") as file:
            file.write(f"# {user_prompt}")
            file.write("\n\n")
            file.write(assistant_answer)
            file.write("\n\n")
            file.write("---")
            file.write("\n\n")
            file.write(f"- Model Name: {AGENT_MODEL_NAME}")
            file.write("\n")
            file.write(f"- Response Time: {response_time:.2f} seconds.")
            file.write("\n\n")
            file.write("---")
            file.write("\n")
    print("-" * 50)
    print(f"'Model Name': {AGENT_MODEL_NAME}")
    print(f"'Response Time': {response_time:.2f} seconds.")
    print("=" * 50)
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception as error:
        print(f"\n[-] {error}!")

    print()
