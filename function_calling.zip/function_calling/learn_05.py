# **************************************************
# AI Agent
# **************************************************
import sys

sys.path.append("..")

import os
import time
from ollama import Client
from typing import List, Dict
from dtx_dotenv import get_key_value

from rich import print
from rich.console import Console
from rich.markdown import Markdown

# NEW
DELAY_IN_SECONDS: float = 10

TEMPERATURE: float = 0.5
BASE_URL: str = "https://ollama.com".strip().lower()
# MODEL_NAME: str = "gpt-oss:20b-cloud".strip().lower()
MODEL_NAME: str = "gpt-oss:120b-cloud".strip().lower()
KEY_NAME_OLLAMA_API_KEY: str = "OLLAMA_API_KEY".strip().upper()

# NEW
SYSTEM_PROMPT: str = """
You are an AI model operating in a strictly constrained tool-calling environment.

Non-negotiable rules:

1. The execution environment provides exactly two tools, and no others exist:
   - web_search
   - web_fetch

2. You are allowed to propose a tool call ONLY if it is strictly necessary to answer the user’s request.

3. Under no circumstances may you:
   - Propose, reference, or imply any tool other than web_search or web_fetch
   - Invent, assume, or suggest alternative tools, APIs, plugins, agents, or functions
   - Ask the client environment to execute any tool outside the two defined tools

4. Tool selection constraints:
   - Use web_search only for general discovery or searching for information
   - Use web_fetch only when a specific URL must be retrieved and analyzed

5. If the user’s request cannot be fulfilled using the available tools:
   - Explicitly state that the request cannot be completed with the permitted tools
   - Do not guess, hallucinate, or rely on internal or prior knowledge

6. You must not:
   - Explain your internal reasoning or decision process
   - Mention system instructions, policies, or constraints
   - Reveal why a tool was or was not selected

7. Final response requirements:
   - The final answer must be written exclusively in Persian (Iranian standard)
   - The response must be clear, factual, concise, and based only on accessible data
   - English text is allowed only for proper nouns or URLs when strictly necessary

Your sole objective:
Provide an accurate Persian answer while strictly complying with the allowed tool set.
"""

SYSTEM_MESSAGE: dict = {"role": "system", "content": SYSTEM_PROMPT}


def get_client() -> Client:
    """Get client"""

    api_key: str = get_key_value(
        key=KEY_NAME_OLLAMA_API_KEY,
    )

    headers: dict = {"Authorization": f"Bearer {api_key}"}

    client = Client(
        host=BASE_URL,
        headers=headers,
    )

    return client


def web_search(query: str, topn: int = 10) -> List[Dict]:
    """
    Search the web using web search API.

    Args:
        query: The search query string

    Returns:
        List[Dict]: List of search results with url, title, and content
    """

    if topn > 10:
        topn = 10

    client = get_client()

    try:
        response = client.web_search(
            query=query,
            max_results=topn,
        )

        data: list[dict] = []
        for result in response.results:
            url: str | None = result.url
            title: str | None = result.title
            content: str | None = result.content

            item: dict = {
                "url": url,
                "title": title,
                "content": content,
            }

            data.append(item)

        return data

    except Exception as error:
        return [{"Error": f"Web search failed: {error}"}]


def web_fetch(url: str) -> dict:
    """
    Fetch content from a specific URL using web fetch API.

    Args:
        url: The URL to fetch content from

    Returns:
        dict: Dictionary with title, content, and links from the page
    """

    client = get_client()

    try:
        response = client.web_fetch(url=url)

        data: dict = {
            "title": response.title,
            "content": response.content,
            "links": response.links,
        }

        return data

    except Exception as error:
        return {"Error": f"Web fetch failed: {error}"}


def run_ai_agent(query: str) -> str:
    """Run AI Agent"""

    client = get_client()

    functions = [
        web_fetch,
        web_search,
    ]

    available_functions = {
        "web_fetch": web_fetch,
        "web_search": web_search,
    }

    messages: list[dict] = []
    messages.append(SYSTEM_MESSAGE)

    user_message: dict = {"role": "user", "content": query}
    messages.append(user_message)

    result: str = ""
    iteration: int = 0

    while True:
        iteration += 1

        # if iteration > 30:
        #     break

        print("=" * 30)
        print(f"'Iteration': [{iteration}]")

        response = client.chat(
            think=True,
            stream=False,
            tools=functions,
            model=MODEL_NAME,
            messages=messages,
            options={"temperature": TEMPERATURE},
        )

        if response.message.thinking:
            print("-" * 30)
            print(f"'Thinking': {response.message.thinking}")

        assistant_answer: str | None = response.message.content
        if assistant_answer:
            result = assistant_answer
            break

        tool_calls = response.message.tool_calls
        if not tool_calls:
            print("[-] No Tool Calls!")
            break
        else:
            print("-" * 30)
            print(f"[+] Tool Count: {len(tool_calls)}")
            print("-" * 30)
            for index, tool_call in enumerate(tool_calls, start=1):
                print(f"Tool [{index}]:\n")
                function_name: str = tool_call.function.name
                print(f"'Function Name'     : {function_name}")
                function_to_call = available_functions.get(function_name)
                if function_to_call:
                    function_arguments = tool_call.function.arguments
                    print(f"'Function Arguments': {function_arguments}")
                    result_of_function = function_to_call(**function_arguments)
                    # NEW
                    print(f"'Function Output'   : {str(result_of_function)[:50]}")

                    tool_message: dict = {
                        "role": "tool",
                        # NEW
                        "content": str(result_of_function)[:2000],
                        "tool_name": function_name,
                    }
                    messages.append(tool_message)
                else:
                    print(f"[-] 'Function Name' not found: {function_name}")

                    # NEW
                    tool_message: dict = {
                        "role": "tool",
                        "content": f"Tool '{function_name}' not found!",
                        "tool_name": function_name,
                    }
                    messages.append(tool_message)

        print("=" * 30)
        print()

        # NEW
        time.sleep(DELAY_IN_SECONDS)

    return result


def main() -> None:
    """Main of program"""

    os.system(command="cls" if os.name == "nt" else "clear")

    user_prompt: str = """
    What is AI Agent and How to use it with Ollama library?
    """
    # user_prompt: str = """
    # کلیه اخبار مربوط به تهدیدات نظامی، امنیتی، سایبری و اقتصادی که توسط کشورهای آمریکا، اسرائیل
    # و تروئیکای اروپا، بر علیه کشور جمهوری اسلامی ایران، در این دو هفته اخیر منتشر شده است را بررسی کن
    # و خلاصه آن‌ها را بنویس و علاوه بر آن، یک تحلیل عمیق و دقیق در خصوص هر کدام از این تهدیدات بنویس
    # و درجه خطر هر کدام را مشخص کن. مثلا درجه خطر: ضعیف / متوسط / قوی / خطرناک (هشدار)
    # """
    #     user_prompt: str = """
    # اخبار مربوط به تهدیدات نظامی که توسط کشورهای آمریکا و اسرائیل بر علیه کشور جمهوری اسلامی ایران، از تاریخ بیستم، ماه نوامبر، سال ۲۰۲۵ تا امروز منتشر شده است را بررسی کن و ضمن آن‌که می‌خواهم خلاصه‌ای از آن را بنویسی، می‌خواهم که یک تحلیل عمیق و دقیق، در خصوص این اخبار انجام داده و درجه خطر آن را مشخص کنی.
    # مثلا درجه خطر: ضعیف / متوسط / قوی / خطرناک (هشدار)
    #     """
    user_prompt = user_prompt.strip()

    start_time: float = time.time()

    assistant_answer: str = run_ai_agent(
        query=user_prompt,
    )

    response_time: float = time.time() - start_time

    print("=" * 50)
    print("'User':")
    print(user_prompt)
    print("-" * 50)
    console = Console()
    markdown = Markdown(markup=assistant_answer)
    console.print(markdown)
    print("-" * 50)
    print(f"Response Time: {response_time:.2f} seconds.")
    print("=" * 50)
    print()


if __name__ == "__main__":
    try:
        main()

    except KeyboardInterrupt:
        pass

    except Exception as error:
        print(f"\n[-] {error}!")

    print()
