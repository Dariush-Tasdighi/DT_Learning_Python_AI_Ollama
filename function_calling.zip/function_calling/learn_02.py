import os
from rich import print


def do_something(full_name: str, age: int) -> None:
    """
    Do something with full name and age

    Args:
      full_name: The full name
      age: The age

    Returns:
      None
    """

    print(f"'Age': {age}")
    print(f"'Full Name': {full_name}")


os.system(command="cls" if os.name == "nt" else "clear")

# Solution (1)
age: int = 30
full_name: str = "John Doe"

do_something(full_name=full_name, age=age)
# /Solution (1)

# Solution (2)
# data: dict = {
#     "age": 30,
#     "full_name": "John Doe",
# }

# do_something(**data)
# /Solution (2)
