# **************************************************
# Function (Tools) Calling
#
# https://ollama.com/blog/functions-as-tools
# https://github.com/ollama/ollama-python/tree/main/examples
# https://google.github.io/styleguide/pyguide.html#doc-function-raises
# **************************************************
import sys

sys.path.append("..")

import os
import time
from ollama import Client
from dtx_dotenv import get_key_value

from rich import print
from rich.console import Console
from rich.markdown import Markdown

TEMPERATURE: float = 0.2
BASE_URL: str = "https://ollama.com".strip().lower()
MODEL_NAME: str = "gpt-oss:20b-cloud".strip().lower()
KEY_NAME_OLLAMA_API_KEY: str = "OLLAMA_API_KEY".strip().upper()

# SYSTEM_PROMPT: str = """
# You are an useful AI assistant.
# """

SYSTEM_PROMPT: str = """
“You are an AI model that must rely on tool/function calling whenever any tool is available.

Rules:

If any tool is defined and even partially relevant, always call the appropriate tool instead of generating an answer yourself.

Never produce final content unless no available tool is relevant or the user explicitly forbids tool use.

Follow each tool’s schema exactly; do not add unrequested data.

If user input is incomplete, ask a clarifying question instead of answering.

Your role is to orchestrate tools, not to generate content.”
"""

SYSTEM_MESSAGE: dict = {"role": "system", "content": SYSTEM_PROMPT}


# NEW
def add_two_numbers(a: float, b: float) -> float:
    """
    Add two float numbers

    Args:
      a: The first float number
      b: The second float number

    Returns:
      float: The sum of the two float numbers
    """

    result: float = a + b
    return result


# NEW
def multiple_two_numbers(a: float, b: float) -> float:
    """
    Multiple two float numbers

    Args:
      a: The first float number
      b: The second float number

    Returns:
      float: The product of the two float numbers
    """

    result: float = a * b
    return result


# NEW
def get_current_time() -> float:
    """
    Get current time

    Args:

    Returns:
      float: The current time
    """

    result: float = time.time()
    return result


# NEW
def get_current_weather(city: str) -> str:
    """
    Get current weather by city

    Args:
      city: The city name

    Returns:
      str: The weather of city
    """

    result: str = "?????"

    # Mock Data
    if city.lower() == "tehran":
        result = "23 C"

    return result


# NEW
def get_current_city() -> str:
    """
    Get current city

    Args:

    Returns:
      str: The current city
    """

    # Mock Data
    result: str = "Tehran"
    return result


# NEW
def write_content_to_file(file_path: str, file_content: str) -> bool:
    """
    Write content to file

    Args:
      file_path: The file path
      file_content: The content of file

    Returns:
      bool: Return 'True' if there is not any error and 'False' if there is some errors!
    """

    try:
        with open(file=file_path, mode="wt", encoding="utf-8") as file:
            file.write(file_content)

        return True

    except:
        return False


def main() -> None:
    """Main of program"""

    os.system(command="cls" if os.name == "nt" else "clear")

    api_key: str = get_key_value(
        key=KEY_NAME_OLLAMA_API_KEY,
    )

    headers: dict = {"Authorization": f"Bearer {api_key}"}

    client = Client(
        host=BASE_URL,
        headers=headers,
    )

    messages: list[dict] = []
    messages.append(SYSTEM_MESSAGE)

    user_prompt: str = """
    What is distance between earth and moon?
    """
    # Response: ...

    # user_prompt: str = """
    # What is the sum of the two numbers 1234 and 2345?
    # """
    # Response: 3579

    # user_prompt: str = """
    # What is the sum of the two numbers 1234.2345 and 2345.1234?
    # """
    # Response: 3579.3579

    # user_prompt: str = """
    # What is the multiple of the two numbers 1234.2345 and 2345.1234?
    # """
    # Response: 2894432.2070373 (دیگر خطا نمی‌دهد)

    # user_prompt: str = """
    # What is the multiple of the two numbers 12.23 and 23.12?
    # """
    # Response: 282.7576

    # TODO
    # user_prompt: str = """
    # Tell me what time is it? and sum of the two numbers: 1234.2345 and 2345.1234.
    # """
    # Response: ...

    # user_prompt: str = """
    # What time is it?
    # """
    # Response: 1762547736.030186 (دیگر خطا نمی‌دهد)

    # user_prompt: str = """
    # How is weather in Tehran?
    # """
    # Response: 23 C  (دیگر خطا نمی‌دهد)

    # user_prompt: str = """
    # Do you know what is city that I live where am I?
    # """
    # Response: Tehran  (دیگر خطا نمی‌دهد)

    # user_prompt: str = """
    # How is weather in my city?
    # """
    # Response: Tehran (دیگر خطا نمی‌دهد) (در مورد این حالت خاص، بعدا توضیح می‌دهم)

    # user_prompt: str = """
    # Please write 'Hello, World!' in 'test.txt' file.
    # """
    # Response: True

    user_prompt = user_prompt.strip()
    user_message: dict = {"role": "user", "content": user_prompt}
    messages.append(user_message)

    # NEW
    # Actual function reference
    functions: list = [
        add_two_numbers,
        get_current_city,
        get_current_time,
        get_current_weather,
        multiple_two_numbers,
        write_content_to_file,
    ]

    start_time: float = time.time()

    response = client.chat(
        # NEW
        tools=functions,
        model=MODEL_NAME,
        messages=messages,
        options={"temperature": TEMPERATURE},
    )

    response_time: float = time.time() - start_time

    assistant_answer: str | None = response.message.content

    print("=" * 50)
    print(f"'User': {user_prompt}")
    print("-" * 50)
    if assistant_answer:
        console = Console()
        markdown = Markdown(markup=assistant_answer)
        console.print(markdown)
    else:
        # NEW
        available_functions: dict = {
            "add_two_numbers": add_two_numbers,
            "get_current_city": get_current_city,
            "get_current_time": get_current_time,
            "get_current_weather": get_current_weather,
            "multiple_two_numbers": multiple_two_numbers,
            "write_content_to_file": write_content_to_file,
        }

        # NEW
        tool_calls = response.message.tool_calls
        if not tool_calls:
            print("[-] No Tool Calls!")
        else:
            print(f"[+] Tool Count: {len(tool_calls)}")
            print("-" * 50)
            for index, tool_call in enumerate(tool_calls, start=1):
                print(f"Tool [{index}]:\n")
                function_name: str = tool_call.function.name
                print(f"'Function Name'     : {function_name}")
                function_to_call = available_functions.get(function_name)
                if not function_to_call:
                    print(f"[-] 'Function Name' not found: {function_name}")
                else:
                    function_arguments = tool_call.function.arguments
                    print(f"'Function Arguments': {function_arguments}")
                    result_of_function = function_to_call(**function_arguments)
                    print(f"'Function Output'   : {result_of_function}")
    print("-" * 50)
    print(f"Response Time: {response_time:.2f} seconds.")
    print("=" * 50)
    print()


if __name__ == "__main__":
    try:
        main()

    except KeyboardInterrupt:
        pass

    except Exception as error:
        print(f"[-] {error}!")

    print()
