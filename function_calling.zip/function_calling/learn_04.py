# **************************************************
# AI Agent
# **************************************************
import sys

sys.path.append("..")

import os
import time
from ollama import Client
from dtx_dotenv import get_key_value

from rich import print
from rich.console import Console
from rich.markdown import Markdown

TEMPERATURE: float = 0.2
BASE_URL: str = "https://ollama.com".strip().lower()
MODEL_NAME: str = "gpt-oss:20b-cloud".strip().lower()
KEY_NAME_OLLAMA_API_KEY: str = "OLLAMA_API_KEY".strip().upper()

# SYSTEM_PROMPT: str = """
# You are an useful AI assistant.
# """

SYSTEM_PROMPT: str = """
“You are an AI model that must rely on tool/function calling whenever any tool is available.

Rules:

If any tool is defined and even partially relevant, always call the appropriate tool instead of generating an answer yourself.

Never produce final content unless no available tool is relevant or the user explicitly forbids tool use.

Follow each tool’s schema exactly; do not add unrequested data.

If user input is incomplete, ask a clarifying question instead of answering.

Your role is to orchestrate tools, not to generate content.”
"""

SYSTEM_MESSAGE: dict = {"role": "system", "content": SYSTEM_PROMPT}


def get_current_city() -> str:
    """
    Get current city

    Args:

    Returns:
      str: The current city
    """

    # Mock Data
    result: str = "Tehran"
    return result


def get_current_weather(city: str) -> str:
    """
    Get current weather by city

    Args:
      city: The city name

    Returns:
      str: The weather of city
    """

    result: str = "?????"

    # Mock Data
    if city.lower() == "tehran":
        result = "23 C"

    return result


def run_ai_agent(query: str) -> str:
    """Run AI Agent"""

    api_key: str = get_key_value(
        key=KEY_NAME_OLLAMA_API_KEY,
    )

    headers: dict = {"Authorization": f"Bearer {api_key}"}

    client = Client(
        host=BASE_URL,
        headers=headers,
    )

    functions: list = [
        get_current_city,
        get_current_weather,
    ]

    available_functions: dict = {
        "get_current_city": get_current_city,
        "get_current_weather": get_current_weather,
    }

    messages: list[dict] = []
    messages.append(SYSTEM_MESSAGE)

    user_message: dict = {"role": "user", "content": query}
    messages.append(user_message)

    result: str = ""
    iteration: int = 0

    while True:
        iteration += 1

        # if iteration > 30:
        #     break

        print("=" * 30)
        print(f"'Iteration': [{iteration}]")

        response = client.chat(
            think=True,
            stream=False,
            tools=functions,
            model=MODEL_NAME,
            messages=messages,
            options={"temperature": TEMPERATURE},
        )

        if response.message.thinking:
            print("-" * 30)
            print(f"'Thinking': {response.message.thinking}")

        assistant_answer: str | None = response.message.content
        if assistant_answer:
            result = assistant_answer
            break

        tool_calls = response.message.tool_calls
        if not tool_calls:
            print("[-] No Tool Calls!")
            break
        else:
            print("-" * 30)
            print(f"[+] Tool Count: {len(tool_calls)}")
            print("-" * 30)
            for index, tool_call in enumerate(tool_calls, start=1):
                print(f"Tool [{index}]:\n")
                function_name: str = tool_call.function.name
                print(f"'Function Name'     : {function_name}")
                function_to_call = available_functions.get(function_name)
                if not function_to_call:
                    print(f"[-] 'Function Name' not found: {function_name}")
                    break
                else:
                    function_arguments = tool_call.function.arguments
                    print(f"'Function Arguments': {function_arguments}")
                    result_of_function = function_to_call(**function_arguments)
                    print(f"'Function Output'   : {result_of_function}")

                    # NEW
                    tool_message: dict = {
                        "role": "tool",
                        "content": result_of_function,
                        "tool_name": function_name,
                    }
                    messages.append(tool_message)
        print("=" * 30)
        print()

    return result


def main() -> None:
    """Main of program"""

    os.system(command="cls" if os.name == "nt" else "clear")

    user_prompt: str = """
    How is weather in my city?
    """
    user_prompt = user_prompt.strip()

    start_time: float = time.time()

    # NEW
    assistant_answer: str = run_ai_agent(
        query=user_prompt,
    )

    response_time: float = time.time() - start_time

    print("=" * 50)
    print("'User':")
    print(user_prompt)
    print("-" * 50)
    console = Console()
    markdown = Markdown(markup=assistant_answer)
    console.print(markdown)
    print("-" * 50)
    print(f"Response Time: {response_time:.2f} seconds.")
    print("=" * 50)
    print()


if __name__ == "__main__":
    try:
        main()

    except KeyboardInterrupt:
        pass

    except Exception as error:
        print(f"[-] {error}!")

    print()
