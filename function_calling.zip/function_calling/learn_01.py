# **************************************************
# Functions (Tools) Calling
#
# https://docs.ollama.com/capabilities/tool-calling
# **************************************************
import sys

sys.path.append("..")

import os
import time
from ollama import Client
from dtx_dotenv import get_key_value

from rich import print
from rich.console import Console
from rich.markdown import Markdown

TEMPERATURE: float = 0.2
BASE_URL: str = "https://ollama.com".strip().lower()
MODEL_NAME: str = "gpt-oss:20b-cloud".strip().lower()
KEY_NAME_OLLAMA_API_KEY: str = "OLLAMA_API_KEY".strip().upper()

SYSTEM_PROMPT: str = """
You are an useful AI assistant.
"""

SYSTEM_MESSAGE: dict = {"role": "system", "content": SYSTEM_PROMPT}


def main() -> None:
    """Main of program"""

    os.system(command="cls" if os.name == "nt" else "clear")

    api_key: str = get_key_value(
        key=KEY_NAME_OLLAMA_API_KEY,
    )

    headers: dict = {"Authorization": f"Bearer {api_key}"}

    client = Client(
        host=BASE_URL,
        headers=headers,
    )

    messages: list[dict] = []
    messages.append(SYSTEM_MESSAGE)

    user_prompt: str = """
    What is the sum of the two numbers 1234 and 2345?
    """
    # Response: 3579

    # user_prompt: str = """
    # What is the sum of the two numbers 1234.2345 and 2345.1234?
    # """
    # Response: 3579.3579

    # user_prompt: str = """
    # What is the multiple of the two numbers 1234.2345 and 2345.1234?
    # """
    # Response: [-] Server disconnected without sending a response.!

    # user_prompt: str = """
    # What is the multiple of the two numbers 12.23 and 23.12?
    # """
    # Response: 282.7576

    # user_prompt: str = """
    # What time is it?
    # """
    # Response: I don’t have access to a real‑time clock, so I can’t tell you the exact current time.
    # If you let me know your time zone or location, I can help you figure out what time it should be
    # there right now. Or you can check a clock on your device or a quick web search for “current time
    # in [your city/time zone].”

    # user_prompt: str = """
    # How is weather in Tehran?
    # """
    # Response: I’m not able to pull in live data, so I can’t give you the exact temperature or forecast
    # for Tehran right now. However, I can share what the city’s climate usually looks like and how you
    # can get the most up‑to‑date information.

    # user_prompt: str = """
    # How is weather in my city?
    # """
    # Response: I’m not able to pull in live weather data, but I can help you find out! Could you let me
    # know which city you’re interested in? Once I have that, I can guide you on how to check the current
    # weather or give you a quick summary of typical conditions for that area.

    # user_prompt: str = """
    # Please write 'Hello, World!' in 'test.txt' file.
    # """
    # Response: ...

    user_prompt = user_prompt.strip()
    user_message: dict = {"role": "user", "content": user_prompt}
    messages.append(user_message)

    start_time: float = time.time()

    response = client.chat(
        model=MODEL_NAME,
        messages=messages,
        options={"temperature": TEMPERATURE},
    )

    response_time: float = time.time() - start_time

    assistant_answer: str | None = response.message.content

    if not assistant_answer:
        assistant_answer = "[-] No content received!"

    print("=" * 50)
    print(f"User: {user_prompt}")
    print("-" * 50)
    # print(assistant_answer)
    console = Console()
    markdown = Markdown(markup=assistant_answer)
    console.print(markdown)
    print("-" * 50)
    print(f"Response Time: {response_time:.2f} seconds.")
    print("=" * 50)
    print()


if __name__ == "__main__":
    try:
        main()

    except KeyboardInterrupt:
        pass

    except Exception as error:
        print(f"[-] {error}!")

    print()
